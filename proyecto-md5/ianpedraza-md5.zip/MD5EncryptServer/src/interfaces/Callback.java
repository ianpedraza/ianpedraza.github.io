package interfaces;

public interface Callback<T> {
    public void onSucces(T value);
    public void onFailed(Exception e);
}
