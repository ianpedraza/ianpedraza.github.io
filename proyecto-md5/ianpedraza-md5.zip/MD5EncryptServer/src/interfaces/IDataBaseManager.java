package interfaces;

import model.User;

public interface IDataBaseManager {
    public void loadData(String file);
    public void saveUser(String file, User user, Callback<Boolean> callback);
    public int findUser(String userName);
    public void registerUser(User user, Callback<Boolean> callback);
}
