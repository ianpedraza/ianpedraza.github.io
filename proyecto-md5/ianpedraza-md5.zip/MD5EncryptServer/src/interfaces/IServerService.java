package interfaces;

public interface IServerService {
    public void listen();
}
