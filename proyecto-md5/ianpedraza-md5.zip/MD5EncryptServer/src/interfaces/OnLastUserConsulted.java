package interfaces;

import model.User;

public interface OnLastUserConsulted {
    public void onCreate(User user);
}
