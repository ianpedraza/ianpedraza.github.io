package network;

import interfaces.Callback;
import interfaces.IDataBaseManager;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import model.User;

public class DataBaseManager implements IDataBaseManager {

    private List<User> users;

    public DataBaseManager() {
        this.users = new ArrayList();
    }

    @Override
    public void loadData(String path) {

        int numberLine = 1;

        try {
            //Abrir el archivo
            File file = new File(path);
            Scanner scanner = new Scanner(file);

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] data = line.split(",");

                if (data.length == 4) {
                    String userId = data[0];
                    String userName = data[1];
                    String password = data[2];
                    String message = data[3];

                    users.add(new User(userId, userName, password, message));
                } else {
                    System.out.println("error al obtener el registro de la líea: " + numberLine);
                }

                numberLine++;
            }

        } catch (FileNotFoundException ex) {
            System.out.println("error al cargar los datos: " + ex);
        }
    }

    @Override
    public int findUser(String userName) {
        int index = -1;

        for (User user : users) {
            if (user.getUserName().equals(userName)) {
                index = users.indexOf(user);
                break;
            }
        }

        return index;
    }

    public List<User> getUsers() {
        return users;
    }

    @Override
    public void registerUser(User user, Callback<Boolean> callback) {
        loadData("users.txt");

        try {
            if (users.size() > 0) {
                int lastId = Integer.parseInt(users.get(users.size() - 1).getUserId());
                user.setUserId(String.valueOf(lastId + 1));
            } else {
                user.setUserId("1");
            }
            
            users.add(user);
            
            if (callback != null) {
                saveUser("users.txt", user, callback);
            }
        } catch (Exception e) {
            if (callback != null) {
                callback.onFailed(e);
            }
        }

    }

    @Override
    public void saveUser(String path, User user, Callback<Boolean> callback) {

        try {
            PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(path, true)));
            out.println(String.format("%s,%s,%s,%s", user.getUserId(), user.getUserName(), user.getPassword(), user.getMessage()));
            out.close();
            
            if (callback != null) {
                callback.onSucces(true);
            }
            
        } catch (Exception e) {
            if (callback != null) {
                callback.onFailed(e);
            }
        }
    }

}
