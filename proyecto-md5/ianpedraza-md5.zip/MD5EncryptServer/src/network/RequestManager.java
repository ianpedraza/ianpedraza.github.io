package network;

import interfaces.Callback;
import interfaces.IRequestManager;
import interfaces.OnLastUserConsulted;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import static model.Encrypt.*;
import static model.MD5.getMd5;
import static model.Mixer.mix;
import static model.REQUEST_TYPE.*;
import model.User;
import static model.Utils.*;
import org.codehaus.jackson.map.ObjectMapper;

public class RequestManager extends Thread implements IRequestManager {

    private BufferedReader entrada = null;
    private PrintWriter salida = null;

    private Socket s;
    private DataBaseManager databaseManager;
    private User user;
    private OnLastUserConsulted listener;

    public RequestManager(Socket s, User user, OnLastUserConsulted listener) {
        this.s = s;
        databaseManager = new DataBaseManager();
        this.listener = listener;
        this.user = user;
    }

    @Override
    public void run() {
        try {
            entrada = new BufferedReader(new InputStreamReader(s.getInputStream()));
            salida = new PrintWriter(new BufferedWriter(new OutputStreamWriter(s.getOutputStream())), true);

            String request = entrada.readLine();

            processRequest(request);

            salida.close();
            entrada.close();
        } catch (Exception ex) {
            System.out.println("Error al leer petición: " + ex);
        }
    }

    @Override
    public void processRequest(String request) {
        String decrypt = decrypt(request);

        String type = decrypt.substring(0, 12);
        String data = decrypt.substring(12, decrypt.length());

        switch (type) {
            case REQUEST_TYPE_USER:
                /*
                 Recibimos el usuario y en caso de ser encontrado
                 se regresa un mensaje aleatorio al usuario
                 */
                System.out.println("Se recibió un usuario: " + data);
                processUser(data);
                break;

            case REQUEST_TYPE_MD5:
                System.out.println("Se recibió un md5: " + data);
                validateLoggin(data);
                break;

            case REQUEST_TYPE_REGISTER:
                /* Voy a registrar un nuevo usuario */
                System.out.println("Se recibió un usuario para registrar: " + data);
                registerNewUser(data);
                break;

            case REQUEST_TYPE_MESSAGE:
                //Recibe un mensaje aleatorio
                System.out.println("Se recibió un mensaje aleatorio: " + data);
                break;

            case REQUEST_TYPE_RESPONSE:
                //Recibe una respuesta de si se loggeo o no
                System.out.println("Se recibió una respuesta: " + data);
                break;

            case REQUEST_TYPE_ERROR:
                //Ocurrio un error
                System.out.println("Se recibió unE error: " + data);
                break;

            default:
                System.out.println("NO_OPERATION_AVAILABLE");
        }
    }

    @Override
    public void processUser(String user) {
        if (!user.isEmpty()) {
            databaseManager.loadData("users.txt");
            int index = databaseManager.findUser(user);

            if (index != -1) {
                User u = databaseManager.getUsers().get(index);

                String randomMessage = createMessage();
                u.setMessage(randomMessage);

                listener.onCreate(u);
                reply(REQUEST_TYPE_MESSAGE, randomMessage);
            } else {
                reply(REQUEST_TYPE_ERROR, "El usuario no existe");
            }
        } else {
            reply(REQUEST_TYPE_ERROR, "Datos invalidos");
        }

    }

    @Override
    public void reply(String type, String reply) {
        try {
            String message = encrypt(type + reply);
            salida = new PrintWriter(new BufferedWriter(new OutputStreamWriter(s.getOutputStream())), true);
            salida.println(message);
            salida.close();
        } catch (Exception ex) {
            System.out.println("Error al leer petición: " + ex);
        }
    }

    @Override
    public void validateLoggin(String md5) {
        if (user != null) {
            String mixed = mix(user.getMessage(), user.getPassword());
            String localMD5 = getMd5(mixed);

            if (md5.equals(localMD5)) {
                reply(REQUEST_TYPE_RESPONSE, "Loggeado");
            } else {
                reply(REQUEST_TYPE_ERROR, "Credenciales invalidas");
            }

        } else {
            System.out.println("null random mesage");
        }
    }

    public Socket getS() {
        return s;
    }

    public void setS(Socket s) {
        this.s = s;
    }

    private void registerNewUser(String userJSON) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            User user = objectMapper.readValue(userJSON, User.class);

            this.databaseManager.registerUser(user, new Callback<Boolean>() {

                @Override
                public void onSucces(Boolean value) {
                    reply(REQUEST_TYPE_RESPONSE, "Usuario Registrado");
                }

                @Override
                public void onFailed(Exception e) {
                    reply(REQUEST_TYPE_ERROR, "No se pudo registrar al usuario");
                }
            });

        } catch (Exception e) {
            reply(REQUEST_TYPE_ERROR, "No se pudo registrar al usuario");
        }
    }

}
