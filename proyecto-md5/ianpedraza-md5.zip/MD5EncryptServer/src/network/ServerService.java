package network;

import interfaces.IServerService;
import interfaces.OnLastUserConsulted;
import java.net.*;
import model.User;

public class ServerService implements IServerService, OnLastUserConsulted {

    private ServerSocket ss;
    private Socket s;
    private User user;

    public void run() {
        try {
            ss = new ServerSocket(9999);
        } catch (Exception ex) {
            System.out.println("error al iniciar el servidor: " + ex);
        }

        System.out.println("Escuchando en el puerto 9999");
        listen();
    }

    @Override
    public void listen() {
        new Thread() {
            @Override
            public void run() {
                while (true) {
                    try {
                        s = ss.accept();
                        System.out.println("Nueva conexion aceptada");
                        new RequestManager(s, user, ServerService.this).start();
                    } catch (Exception ex) {
                        System.out.println("error al leer los datos: " + ex);
                    }
                }
            }
        }.start();
    }

    @Override
    public void onCreate(User user) {
        this.user = user;
    }

}
