package model;

import java.util.Arrays;

public class Mixer {

    public static String mix(String message, String data) {
        char[] messageArray = message.toCharArray();
        int position = (int) Math.ceil(message.length() * 0.3);
        int steep = (int) Math.floor((message.length()*0.7) / data.length());

        for (char c : data.toCharArray()) {
            if (position <= message.length()) {
                messageArray[position] = c;
            } else {
                break;
            }
            position += steep;
        }

        return Arrays.toString(messageArray);
    }

}
