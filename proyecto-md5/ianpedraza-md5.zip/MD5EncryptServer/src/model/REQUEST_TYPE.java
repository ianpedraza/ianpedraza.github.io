package model;

public abstract class REQUEST_TYPE{
    public static final String REQUEST_TYPE_USER = "USER********";
    public static final String REQUEST_TYPE_MESSAGE = "MESSAGE*****";
    public static final String REQUEST_TYPE_MD5 = "MD5*********";
    public static final String REQUEST_TYPE_REGISTER = "REGISTER****";
    public static final String REQUEST_TYPE_RESPONSE = "RESPONSE****";
    public static final String REQUEST_TYPE_ERROR= "ERROR*******";
}
