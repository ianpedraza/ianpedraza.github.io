package view;

/*
    Pedraza Celon Ian Yael 201719516
    ianpedrazacelon@gmail.com
*/

import java.io.UnsupportedEncodingException;
import static model.MD5.getMd5;
import static model.MD5.getMd5Test;
import static model.Utils.createMessage;
import network.ServerService;

public class Main {

    public static void main(String[] args) throws UnsupportedEncodingException {
        ServerService serverService = new ServerService();
        serverService.run();

        /*
         for (int i = 0; i < 10000; i++) {
         String cadena = createMessage();

         String hash = getMd5(cadena);
         String systemMD5 = getMd5Test(cadena);

         Boolean result = hash.equals(systemMD5);

         if (!result) {
         throw new IllegalArgumentException("Falló en la prueba: " + i);
         }
         }
        */
    }

}
