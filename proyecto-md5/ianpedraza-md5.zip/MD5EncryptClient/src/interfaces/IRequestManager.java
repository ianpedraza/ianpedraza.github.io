package interfaces;

public interface IRequestManager {
    public void processRequest(String request, OnRequestListener listener, Callback<String> callback);
    public void processRandomMessage(String randomMessage);
}
