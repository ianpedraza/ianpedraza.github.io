package interfaces;

public interface IClientService {
    public boolean conect();
    public void close();
    public void request(String type, String data);
    public void startReading();
    public void login(String user, String pasword);
    public void register(String user, String pasword);
}
