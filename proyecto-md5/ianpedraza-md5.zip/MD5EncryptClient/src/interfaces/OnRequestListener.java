package interfaces;

public interface OnRequestListener {
    public void onRequest(String type, String request);
}
