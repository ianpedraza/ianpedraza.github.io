package network;

import interfaces.Callback;
import interfaces.IClientService;
import interfaces.OnRequestListener;
import java.net.*;
import java.io.*;
import java.util.concurrent.TimeUnit;
import model.RequestManager;
import static model.Encrypt.*;
import static model.REQUEST_TYPE.REQUEST_TYPE_REGISTER;
import static model.REQUEST_TYPE.REQUEST_TYPE_USER;
import model.User;
import org.codehaus.jackson.map.ObjectMapper;

public class ClientService implements IClientService {

    private Socket socket;
    private BufferedReader entrada;
    private PrintWriter salida;
    private String server;
    private int port;
    private RequestManager requestManager;
    private Callback<String> callback;

    public ClientService(String server, int port, Callback<String> callback) {
        this.port = port;
        this.server = server;
        this.requestManager = new RequestManager();
        this.callback = callback;
        startReading();
    }

    @Override
    public boolean conect() {
        try {
            //String servidor = "localhost";
            //int puerto = 9999;

            socket = new Socket(server, port);
            entrada = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            salida = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);
        } catch (Exception ex) {
            System.out.println("error al conectar al servidor: " + ex);
            callback.onSucces("Error al conectarse al servidor");
            return false;
        }

        return true;
    }

    @Override
    public void close() {
        if (!socket.isClosed()) {
            try {
                socket.close();
            } catch (IOException ex) {
                System.out.println("error al cerrar conexión: " + ex);
            }
        }
    }

    @Override
    public void startReading() {
        new Thread() {
            @Override
            public void run() {
                while (true) {
                    try {
                        if (socket != null && socket.isConnected() && !socket.isClosed()) {

                            String read = entrada.readLine();
                            close();

                            requestManager.processRequest(read, new OnRequestListener() {
                                @Override
                                public void onRequest(String type, String request) {
                                    request(type, request);
                                }
                            }, new Callback<String>() {
                                @Override
                                public void onSucces(String value) {
                                    if (callback != null) callback.onSucces(value);
                                }

                                @Override
                                public void onFailed(Exception e) {
                                    if (callback != null) callback.onFailed(e);
                                }

                            });
                        }

                        TimeUnit.SECONDS.sleep(1);
                    } catch (IOException | InterruptedException ex) {
                        System.out.println("Error al obtener datos: " + ex);
                    }
                }
            }
        }.start();
    }

    @Override
    public void request(String type, String data) {
        String encrypt = encrypt(type + data);

        if (conect()) {
            salida.println(encrypt);
        }
    }

    @Override
    public void login(String user, String pasword) {
        requestManager.setPassword(pasword);
        request(REQUEST_TYPE_USER, user);
    }

    @Override
    public void register(String user, String password) {

        try {
            ObjectMapper mapper = new ObjectMapper();
            String jsonString = mapper.writeValueAsString(new User(user, password));
            request(REQUEST_TYPE_REGISTER, jsonString);
        } catch (IOException ex) {
            System.out.println("error: no se pudo enviar la información al registro");
        }

    }
}
