package model;

import java.math.BigInteger; 
import java.security.MessageDigest; 
import java.security.NoSuchAlgorithmException;   

public class MD5 { 
    
    private final static int TAM_BLOQUE = 16;
    private final static int TAM_BLOQUE_BYTES = TAM_BLOQUE * 4;

    private static byte[] bytesSobrantes;
    private static int longitudSobrante;
    private static long tamProcesado;

    /* Vector T */
    private static final int[] T = new int[64];

    /* vectores publicos */
    private final static int[] vectores = new int[4];

    /* vectores iniciales */
    private final static int[] vectoresIniciales = {
        0x67452301,
        0xefcdab89,
        0x98badcfe,
        0x10325476
    };

    /* Vector X */
    private static final int[] X = {
        7, 12, 17, 22,
        5, 9, 14, 20,
        4, 11, 16, 23,
        6, 10, 15, 21
    };

    private static void init() {
        
        for (int i = 0; i < 64; i++) {
            T[i] = (int) (long) ((1L << 32) * Math.abs(Math.sin(i + 1)));
        }

        reiniciar();
    }

    public static String getMd5(String cadena) {
        init();
        
        byte[] input = cadena.getBytes();
        return procesar(input, input.length);
    }

    private static String procesar(byte[] input, int tam) {
        int[] palabra = new int[TAM_BLOQUE];
        int index = 0;

        /* Procesamos cada bloque de palabras */
        while ((tam - index) >= (TAM_BLOQUE_BYTES)) {
            for (int i = 0; i < TAM_BLOQUE; i++) {
                palabra[i] = BitUtils.toInt(input, index);
                index += 4;
            }

            procesarPalabra(palabra);
            tamProcesado += TAM_BLOQUE_BYTES;
        }

        /* Actualizamos el tamaño restante */
        longitudSobrante = tam - index;

        if (longitudSobrante > 0) {
            bytesSobrantes = new byte[TAM_BLOQUE_BYTES];
            System.arraycopy(input, index, bytesSobrantes, 0, longitudSobrante);
        } else {
            bytesSobrantes = null;
        }

        return BitUtils.toHexString(bloqueRelleno());
    }

    private static int[] toEndian(int[] block) {
        int[] x = new int[TAM_BLOQUE];

        for (int i = 0; i < TAM_BLOQUE; i++) {
            x[i] = BitUtils.invertir(block[i]);
        }

        return x;
    }

    private static int f(int x, int y, int z) {
        return (x & y) | ((~x) & z);
    }

    private static int g(int x, int y, int z) {
        return (x & z) | (y & (~z));
    }

    private static int h(int x, int y, int z) {
        return (x ^ y ^ z);
    }

    private static int i(int x, int y, int z) {
        return (y ^ (x | (~z)));
    }

    private static int ff(int a, int b, int c, int d, int x, int s, int ac) {
        return Integer.rotateLeft(a + f(b, c, d) + x + ac, s) + b;
    }

    private static int gg(int a, int b, int c, int d, int x, int s, int ac) {
        return Integer.rotateLeft(a + g(b, c, d) + x + ac, s) + b;
    }

    private static int hh(int a, int b, int c, int d, int x, int s, int ac) {
        return Integer.rotateLeft(a + h(b, c, d) + x + ac, s) + b;
    }

    private static int ii(int a, int b, int c, int d, int x, int s, int ac) {
        return Integer.rotateLeft(a + i(b, c, d) + x + ac, s) + b;
    }

    private static void procesarPalabra(int[] palabra) {
        /* Obtenemos los vectores almacenados */
        int a = vectores[0];
        int b = vectores[1];
        int c = vectores[2];
        int d = vectores[3];

        /* Invvertimos a endian */
        int[] palabraEndian = toEndian(palabra);        
        
        /* Vuelta 1 */
        a = ff(a, b, c, d, palabraEndian[0], X[0], T[0]);

        d = ff(d, a, b, c, palabraEndian[1], X[1], T[1]);

        c = ff(c, d, a, b, palabraEndian[2], X[2], T[2]);

        b = ff(b, c, d, a, palabraEndian[3], X[3], T[3]);

        a = ff(a, b, c, d, palabraEndian[4], X[0], T[4]);

        d = ff(d, a, b, c, palabraEndian[5], X[1], T[5]);

        c = ff(c, d, a, b, palabraEndian[6], X[2], T[6]);

        b = ff(b, c, d, a, palabraEndian[7], X[3], T[7]);

        a = ff(a, b, c, d, palabraEndian[8], X[0], T[8]);

        d = ff(d, a, b, c, palabraEndian[9], X[1], T[9]);

        c = ff(c, d, a, b, palabraEndian[10], X[2], T[10]);

        b = ff(b, c, d, a, palabraEndian[11], X[3], T[11]);

        a = ff(a, b, c, d, palabraEndian[12], X[0], T[12]);

        d = ff(d, a, b, c, palabraEndian[13], X[1], T[13]);

        c = ff(c, d, a, b, palabraEndian[14], X[2], T[14]);

        b = ff(b, c, d, a, palabraEndian[15], X[3], T[15]);

        /* Vuelta 2 */
        a = gg(a, b, c, d, palabraEndian[1], X[4], T[16]);

        d = gg(d, a, b, c, palabraEndian[6], X[5], T[17]);

        c = gg(c, d, a, b, palabraEndian[11], X[6], T[18]);

        b = gg(b, c, d, a, palabraEndian[0], X[7], T[19]);

        a = gg(a, b, c, d, palabraEndian[5], X[4], T[20]);

        d = gg(d, a, b, c, palabraEndian[10], X[5], T[21]);

        c = gg(c, d, a, b, palabraEndian[15], X[6], T[22]);

        b = gg(b, c, d, a, palabraEndian[4], X[7], T[23]);

        a = gg(a, b, c, d, palabraEndian[9], X[4], T[24]);

        d = gg(d, a, b, c, palabraEndian[14], X[5], T[25]);

        c = gg(c, d, a, b, palabraEndian[3], X[6], T[26]);

        b = gg(b, c, d, a, palabraEndian[8], X[7], T[27]);

        a = gg(a, b, c, d, palabraEndian[13], X[4], T[28]);

        d = gg(d, a, b, c, palabraEndian[2], X[5], T[29]);

        c = gg(c, d, a, b, palabraEndian[7], X[6], T[30]);

        b = gg(b, c, d, a, palabraEndian[12], X[7], T[31]);

        /* Vuelta 3 */
        a = hh(a, b, c, d, palabraEndian[5], X[8], T[32]);

        d = hh(d, a, b, c, palabraEndian[8], X[9], T[33]);

        c = hh(c, d, a, b, palabraEndian[11], X[10], T[34]);

        b = hh(b, c, d, a, palabraEndian[14], X[11], T[35]);

        a = hh(a, b, c, d, palabraEndian[1], X[8], T[36]);

        d = hh(d, a, b, c, palabraEndian[4], X[9], T[37]);

        c = hh(c, d, a, b, palabraEndian[7], X[10], T[38]);

        b = hh(b, c, d, a, palabraEndian[10], X[11], T[39]);

        a = hh(a, b, c, d, palabraEndian[13], X[8], T[40]);

        d = hh(d, a, b, c, palabraEndian[0], X[9], T[41]);

        c = hh(c, d, a, b, palabraEndian[3], X[10], T[42]);

        b = hh(b, c, d, a, palabraEndian[6], X[11], T[43]);

        a = hh(a, b, c, d, palabraEndian[9], X[8], T[44]);

        d = hh(d, a, b, c, palabraEndian[12], X[9], T[45]);

        c = hh(c, d, a, b, palabraEndian[15], X[10], T[46]);

        b = hh(b, c, d, a, palabraEndian[2], X[11], T[47]);

        /* Vuelta 4 */
        a = ii(a, b, c, d, palabraEndian[0], X[12], T[48]);

        d = ii(d, a, b, c, palabraEndian[7], X[13], T[49]);

        c = ii(c, d, a, b, palabraEndian[14], X[14], T[50]);

        b = ii(b, c, d, a, palabraEndian[5], X[15], T[51]);

        a = ii(a, b, c, d, palabraEndian[12], X[12], T[52]);

        d = ii(d, a, b, c, palabraEndian[3], X[13], T[53]);

        c = ii(c, d, a, b, palabraEndian[10], X[14], T[54]);

        b = ii(b, c, d, a, palabraEndian[1], X[15], T[55]);

        a = ii(a, b, c, d, palabraEndian[8], X[12], T[56]);

        d = ii(d, a, b, c, palabraEndian[15], X[13], T[57]);

        c = ii(c, d, a, b, palabraEndian[6], X[14], T[58]);

        b = ii(b, c, d, a, palabraEndian[13], X[15], T[59]);

        a = ii(a, b, c, d, palabraEndian[4], X[12], T[60]);

        d = ii(d, a, b, c, palabraEndian[11], X[13], T[61]);

        c = ii(c, d, a, b, palabraEndian[2], X[14], T[62]);

        b = ii(b, c, d, a, palabraEndian[9], X[15], T[63]);

        /* Hacemos la suma de los recultados a los vectores */
        vectores[0] += a;
        vectores[1] += b;
        vectores[2] += c;
        vectores[3] += d;
    }

    private static void reiniciar() {
        /* Restauramos los vectores a los valores iniciales */
        for (int i = 0; i < vectores.length; i++) {
            vectores[i] = vectoresIniciales[i];
        }

        bytesSobrantes = null;
        longitudSobrante = 0;
        tamProcesado = 0;
    }

    private static byte[] bloqueRelleno() {
        int[] palabra = new int[TAM_BLOQUE];

        tamProcesado += longitudSobrante;

        /* Validar si hay un bloque restante */
        if (bytesSobrantes != null) {
            bytesSobrantes[longitudSobrante++] = (byte) 128;

            if (longitudSobrante > TAM_BLOQUE_BYTES - 8) {
                /* Aplicamos el relleno */

                for (; longitudSobrante < TAM_BLOQUE_BYTES; longitudSobrante++) {
                    bytesSobrantes[longitudSobrante] = (byte) 0;
                }

                int i = 0;

                for (int j = 0; j < TAM_BLOQUE; j++) {
                    palabra[j] = BitUtils.toInt(bytesSobrantes, i);
                    i += 4;
                }

                procesarPalabra(palabra);

                bytesSobrantes = new byte[TAM_BLOQUE_BYTES];
                longitudSobrante = 0;
            }
        } else {
            bytesSobrantes = new byte[TAM_BLOQUE_BYTES];
            longitudSobrante = 0;
            bytesSobrantes[longitudSobrante++] = (byte) 128;
        }

        for (; longitudSobrante < (TAM_BLOQUE_BYTES - 8); longitudSobrante++) {
            bytesSobrantes[longitudSobrante] = (byte) 0;
        }

        BitUtils.toBytesBigEndian(tamProcesado * 8, bytesSobrantes, longitudSobrante);

        int i = 0;

        for (int k = 0; k < TAM_BLOQUE; k++) {
            palabra[k] = BitUtils.toInt(bytesSobrantes, i);
            i += 4;
        }

        procesarPalabra(palabra);

        byte[] byteArray = new byte[16];

        for (int k = 0; k < 4; k++) {
            BitUtils.toBytesBigEndian(vectores[k], byteArray, k * 4);
        }

        /* Reiniciarmos los valores por defecto */
        reiniciar();

        return byteArray;
    }
    
    public static String getMd5Test(String input) { 
        try { 
  
            // Static getInstance method is called with hashing MD5 
            MessageDigest md = MessageDigest.getInstance("MD5"); 
  
            // digest() method is called to calculate message digest 
            //  of an input digest() return array of byte 
            byte[] messageDigest = md.digest(input.getBytes());             
            
            // Convert byte array into signum representation 
            BigInteger no = new BigInteger(1, messageDigest); 
  
            // Convert message digest into hex value 
            String hashtext = no.toString(16); 
            
            while (hashtext.length() < 32) { 
                hashtext = "0" + hashtext; 
            } 
            
            return hashtext; 
        }  
  
        // For specifying wrong message digest algorithms 
        catch (NoSuchAlgorithmException e) { 
            throw new RuntimeException(e); 
        } 
    }
    
}
