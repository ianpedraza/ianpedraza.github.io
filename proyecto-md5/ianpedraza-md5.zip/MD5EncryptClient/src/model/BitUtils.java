package model;

public class BitUtils {

    public static int toInt(byte[] b, int offset) {
        return ((b[offset] & 0xFF) << 24) | ((b[offset + 1] & 0xFF) << 16) | ((b[offset + 2] & 0xFF) << 8) | (b[offset + 3] & 0xFF);
    }

    public static void toBytesBigEndian(int a, byte[] bytes, int offset) {
        bytes[offset + 3] = (byte) ((a >>> 24) & 0x000000FF);
        bytes[offset + 2] = (byte) ((a >>> 16) & 0x000000FF);
        bytes[offset + 1] = (byte) ((a >>> 8) & 0x000000FF);
        bytes[offset] = (byte) ((a) & 0x000000FF);
    }

    public static void toBytesBigEndian(long a, byte[] bytes, int offset) {
        for (int i = 0; i < 8; i++) {
            bytes[offset + i] = (byte) (a & 0x000000FF);
            a = a >>> 8;
        }
    }

    public static int invertir(int x) {
        return (x >>> 24) | ((x >>> 8) & 0x0000FF00) | ((x << 8) & 0x00FF0000) | (x << 24);
    }

    public static String toHexString(byte[] b) {
        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < b.length; i++) {
            sb.append(String.format("%02x", b[i]));
        }

        return sb.toString();
    }

}
