package model;

import interfaces.Callback;
import interfaces.IRequestManager;
import interfaces.OnRequestListener;
import static model.REQUEST_TYPE.*;
import static model.Encrypt.*;
import static model.MD5.getMd5;
import static model.Mixer.mix;


public class RequestManager implements IRequestManager {

    private OnRequestListener listener;
    private String password;

    @Override
    public void processRequest(String request, OnRequestListener listener, Callback<String> callback) {
        if (request != null) {
            this.listener = listener;

            String decrypt = decrypt(request);

            String type = decrypt.substring(0, 12);
            String data = decrypt.substring(12, decrypt.length());

            switch (type) {

                case REQUEST_TYPE_MESSAGE:
                    /* Recibe mensaje aleatorio */
                    System.out.println("Se recibió un mensaje aleatorio" + data);
                    processRandomMessage(data);
                    break;

                case REQUEST_TYPE_RESPONSE:
                    System.out.println("Se recibió una respuesta: " + data);
                    if (callback != null) callback.onSucces(data);
                    break;

                case REQUEST_TYPE_ERROR:
                    System.out.println("error: " + data);
                    if (callback != null) callback.onSucces("error: " + data);
                    break;

                default:
                    System.out.println("NO_OPERATION_AVAILABLE");
            }
        }
    }

    @Override
    public void processRandomMessage(String randomMessage) {
        System.out.println("randomMessageSize: " + randomMessage.length());
        
        if (password != null) {
            String mixed = mix(randomMessage, password);
            String md5 = getMd5(mixed);

            listener.onRequest(REQUEST_TYPE_MD5, md5);
        } else {
            System.out.println("credencial nula");
        }
    }

    public OnRequestListener getListener() {
        return listener;
    }

    public void setListener(OnRequestListener listener) {
        this.listener = listener;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

}
