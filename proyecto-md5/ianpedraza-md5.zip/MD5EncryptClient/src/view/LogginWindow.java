package view;

import interfaces.Callback;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import network.ClientService;

public class LogginWindow extends JFrame implements Callback<String> {

    private final String font = "Arial";
    private final int font_size = 14;
    private ClientService client;
    private JButton btnRegister, btnLogin;

    public LogginWindow() {
        client = new ClientService("localhost", 9999, this);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Login");
        
        ImageIcon icon = new ImageIcon("images/icon.png");
        setIconImage(icon.getImage());
        
        setLayout(null);
        setBounds(10, 10, 1070, 600);

        initComponents();

        setResizable(false);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void initComponents() {
        initLeftPanel();
        initMainPanel();
    }

    private void initLeftPanel() {
        try {
            JPanel panel = new JPanel();
            panel.setBounds(0, 0, 700, 600);

            BufferedImage logo = ImageIO.read(new File("images/image.jpg"));
            JLabel labelLogo = new JLabel(new ImageIcon(logo));
            labelLogo.setSize(700, 600);

            panel.add(labelLogo);
            add(panel, BorderLayout.WEST);
        } catch (Exception e) {
            System.out.println("Error: " + e);
        }
    }

    private void initMainPanel() {
        JPanel panel = new JPanel();
        panel.setBounds(700, 0, 370, 600);
        panel.setBackground(Color.white);
        panel.setLayout(null);

        JLabel tvBienvenido = new JLabel("Welcome");
        tvBienvenido.setBounds(45, 50, 350, 80);
        tvBienvenido.setFont(new Font("Brush Script MT", Font.BOLD, 85));
        tvBienvenido.setForeground(Color.black);
        
        JLabel tvUser = new JLabel("Nombre de usuario");
        tvUser.setBounds(35, 170, 300, 30);
        tvUser.setFont(new Font(font, Font.ROMAN_BASELINE, font_size));

        JTextField tfUser = new JTextField();
        tfUser.setBounds(35, 200, 300, 30);
        tfUser.setFont(new Font(font, Font.ROMAN_BASELINE, font_size));

        JLabel tvPassword = new JLabel("Contraseña");
        tvPassword.setBounds(35, 240, 300, 30);
        tvPassword.setFont(new Font(font, Font.ROMAN_BASELINE, font_size));

        JPasswordField tfPassword = new JPasswordField();
        tfPassword.setBounds(35, 270, 300, 30);
        tfPassword.setFont(new Font(font, Font.ROMAN_BASELINE, font_size));

        btnLogin = new JButton("INGRESAR");
        btnLogin.setBounds(35, 330, 300, 30);
        btnLogin.setFont(new Font(font, Font.BOLD, font_size));
        btnLogin.setBackground(Color.red);
        btnLogin.setForeground(Color.white);
        btnLogin.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btnRegister = new JButton("REGISTRAR");
        btnRegister.setBounds(35, 500, 300, 30);
        btnRegister.setFont(new Font(font, Font.ROMAN_BASELINE, font_size));
        btnRegister.setBackground(Color.white);
        btnRegister.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btnLogin.addActionListener((ActionEvent e) -> {
            String user = tfUser.getText();
            String password = tfPassword.getText();

            if (!user.isEmpty()) {
                if (!password.isEmpty()) {
                    btnLogin.setEnabled(false);
                    btnRegister.setEnabled(false);

                    client.login(user, password);
                } else {
                    onSucces("La contraseña esta vacia");
                }
            } else {
                onSucces("El usuario esta vacio");
            }
        });

        btnRegister.addActionListener((ActionEvent e) -> {
            String user = tfUser.getText();
            String password = tfPassword.getText();

            if (!user.isEmpty()) {
                if (!password.isEmpty()) {
                    btnLogin.setEnabled(false);
                    btnRegister.setEnabled(false);

                    client.register(user, password);
                } else {
                    onSucces("La contraseña esta vacia");
                }
            } else {
                onSucces("El usuario esta vacio");
            }
        });
        
        panel.add(tvBienvenido);
        panel.add(tvUser);
        panel.add(tfUser);
        panel.add(tvPassword);
        panel.add(tfPassword);
        panel.add(btnLogin);
        panel.add(btnRegister);

        add(panel, BorderLayout.CENTER);
    }

    @Override
    public void onSucces(String value) {
        btnLogin.setEnabled(true);
        btnRegister.setEnabled(true);

        JOptionPane.showMessageDialog(this, value);
    }

    @Override
    public void onFailed(Exception e) {
        btnLogin.setEnabled(true);
        btnRegister.setEnabled(true);

        System.out.println(e);
    }

}
