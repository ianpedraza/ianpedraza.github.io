package view;

/*
    Pedraza Celon Ian Yael 201719516
    ianpedrazacelon@gmail.com
*/

public class Main {

    public static void main(String[] args) {
        //ClientService client = new ClientService("localhost", 9999);
        //client.login("ianpedraza", "123456");
        //client.register("ianpedraza", "123456");
        
        LogginWindow logginWindow = new LogginWindow();
    }
    
}
